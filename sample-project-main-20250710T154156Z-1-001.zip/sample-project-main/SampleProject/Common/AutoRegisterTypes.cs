﻿namespace Common
{
    public enum AutoRegisterTypes
    {
        Singleton = 1,
        Scope = 2
    }
}