﻿namespace BusinessEntities
{
    public enum UserTypes
    {
        Admin = 1,
        Employee = 2,
        Customer = 3
    }
}